// Runtime layout registry for route composition.
// 修正說明：補齊 route layout 字串到實際 layout render model 的掛載入口，避免執行期出現 layout 未實做。

pub mod empty_layout;
pub mod layout;

use crate::backend::logging;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LayoutRenderContext {
    pub route_name: String,
    pub route_path: String,
    pub component_name: String,
    pub page_rows: Vec<(String, String)>,
}

impl LayoutRenderContext {
    pub fn new(route_name: impl Into<String>, route_path: impl Into<String>, component_name: impl Into<String>, page_rows: Vec<(String, String)>) -> Self {
        Self { route_name: route_name.into(), route_path: route_path.into(), component_name: component_name.into(), page_rows }
    }
}

pub fn supported_layouts() -> Vec<&'static str> {
    vec!["Layout", "EmptyLayout"]
}

pub fn render_layout(layout_name: &str, context: LayoutRenderContext) -> Result<Vec<(String, String)>, String> {
    logging::debug("frontend.layouts", "render_layout", format!("layout={}, route={}", layout_name, context.route_path));
    match layout_name {
        "Layout" => render_main_layout(context),
        "EmptyLayout" => render_empty_layout(context),
        other => Err(format!("layout {other} is not registered")),
    }
}

fn render_main_layout(context: LayoutRenderContext) -> Result<Vec<(String, String)>, String> {
    let component = layout::LayoutComponent::default();
    let mut rows = layout::render_model(&component);
    append_route_context(&mut rows, "Layout", context);
    Ok(rows)
}

fn render_empty_layout(context: LayoutRenderContext) -> Result<Vec<(String, String)>, String> {
    let component = empty_layout::EmptyLayoutComponent::default();
    let mut rows = empty_layout::render_model(&component);
    append_route_context(&mut rows, "EmptyLayout", context);
    Ok(rows)
}

fn append_route_context(rows: &mut Vec<(String, String)>, layout_name: &str, context: LayoutRenderContext) {
    rows.push(("layout:name".to_string(), layout_name.to_string()));
    rows.push(("layout:route_name".to_string(), context.route_name));
    rows.push(("layout:route_path".to_string(), context.route_path));
    rows.push(("layout:component".to_string(), context.component_name));
    for (key, value) in context.page_rows {
        rows.push((format!("layout:child:{key}"), value));
    }
}
