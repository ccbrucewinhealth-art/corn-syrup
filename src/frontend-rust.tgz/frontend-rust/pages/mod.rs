// Runtime page registry for route composition.
// 修正說明：補齊 route component 字串到實際頁面 render model 的掛載入口，避免頁面或 layout 組裝時落入未實做。

pub mod add_status_page;
pub mod dashboard;
pub mod dashboard_home;
pub mod details;
pub mod edit_maintenance;
pub mod edit_monitor;
pub mod entry;
pub mod list;
pub mod manage_maintenance;
pub mod manage_status_page;
pub mod not_found;
pub mod settings;
pub mod setup;
pub mod setup_database;
pub mod status_page;

use crate::backend::logging;

pub fn supported_pages() -> Vec<&'static str> {
    vec![
        "EntryPage",
        "SetupPage",
        "SetupDatabasePage",
        "DashboardPage",
        "DashboardHomePage",
        "ListPage",
        "DetailsPage",
        "EditMonitorPage",
        "EditMaintenancePage",
        "ManageMaintenancePage",
        "SettingsPage",
        "StatusPage",
        "ManageStatusPage",
        "AddStatusPage",
        "NotFoundPage",
    ]
}

pub fn render_page(component_name: &str, route_path: &str) -> Result<Vec<(String, String)>, String> {
    logging::debug("frontend.pages", "render_page", format!("component={}, route={}", component_name, route_path));
    let mut rows = match component_name {
        "EntryPage" => entry::render_model(&entry::EntryComponent::default()),
        "SetupPage" => setup::render_model(&setup::SetupComponent::default()),
        "SetupDatabasePage" => setup_database::render_model(&setup_database::SetupDatabaseComponent::default()),
        "DashboardPage" => dashboard::render_model(&dashboard::DashboardComponent::default()),
        "DashboardHomePage" => dashboard_home::render_model(&dashboard_home::DashboardHomeComponent::default()),
        "ListPage" => list::render_model(&list::ListComponent::default()),
        "DetailsPage" => details::render_model(&details::DetailsComponent::default()),
        "EditMonitorPage" => edit_monitor::render_model(&edit_monitor::EditMonitorComponent::default()),
        "EditMaintenancePage" => edit_maintenance::render_model(&edit_maintenance::EditMaintenanceComponent::default()),
        "ManageMaintenancePage" => manage_maintenance::render_model(&manage_maintenance::ManageMaintenanceComponent::default()),
        "SettingsPage" => settings::render_model(&settings::SettingsComponent::default()),
        "StatusPage" => status_page::render_model(&status_page::StatusPageComponent::default()),
        "ManageStatusPage" => manage_status_page::render_model(&manage_status_page::ManageStatusPageComponent::default()),
        "AddStatusPage" => add_status_page::render_model(&add_status_page::AddStatusPageComponent::default()),
        "NotFoundPage" => not_found::render_model(&not_found::NotFoundComponent::default()),
        other => return Err(format!("page component {other} is not registered")),
    };
    rows.push(("page:component".to_string(), component_name.to_string()));
    rows.push(("page:resolved_route".to_string(), route_path.to_string()));
    Ok(rows)
}
