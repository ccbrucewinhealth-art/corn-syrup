// checklist No.251 translated from backend/main.js
// 補強說明：根入口改為掛載 AppComponent，經 router resolve 後組裝 page 與 layout，避免執行期 layout 未實做。
// 演算法：先建立 App 狀態，再依目前 route 解析頁面與 layout，最後輸出完整 render model 供 Yew view 掛載。
mod app;
mod backend;
mod layouts;
mod pages;
mod router;
use crate::backend::logging;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UiField { pub name: String, pub label: String, pub required: bool, pub value: Option<String> }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UiAction { pub name: String, pub label: String, pub target_route: Option<String> }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MainComponent {
    pub source_path: &'static str,
    pub title: String,
    pub route: String,
    pub loading: bool,
    pub error: Option<String>,
    pub fields: Vec<UiField>,
    pub actions: Vec<UiAction>,
}

impl Default for MainComponent {
    fn default() -> Self {
        logging::debug("frontend.main", "default", "create default component state");
        Self { source_path: "backend/main.js", title: "前端入口".to_string(), route: "/main".to_string(), loading: false, error: None, fields: default_fields(), actions: default_actions() }
    }
}

impl MainComponent {
    pub fn validate(&self) -> Result<(), String> {
        logging::debug("frontend.main", "validate", format!("route={}", self.route));
        if self.title.trim().is_empty() { return Err("component title is required".to_string()); }
        if self.route.trim().is_empty() { return Err("component route is required".to_string()); }
        Ok(())
    }

    pub fn apply_route(&mut self, route: impl Into<String>) -> Result<(), String> {
        let route = route.into();
        logging::debug("frontend.main", "apply_route", &route);
        if route.trim().is_empty() { return Err("route is required".to_string()); }
        self.route = route;
        Ok(())
    }

    pub fn set_loading(&mut self, loading: bool) {
        logging::debug("frontend.main", "set_loading", loading.to_string());
        self.loading = loading;
    }

    pub fn set_error(&mut self, error: Option<String>) {
        logging::debug("frontend.main", "set_error", error.clone().unwrap_or_else(|| "none".to_string()));
        self.error = error;
    }

    pub fn update_field(&mut self, name: &str, value: impl Into<String>) -> Result<(), String> {
        logging::debug("frontend.main", "update_field", name);
        let value = value.into();
        if let Some(field)=self.fields.iter_mut().find(|f| f.name == name) { field.value = Some(value); Ok(()) } else { Err(format!("field {name} not found")) }
    }

    pub fn render_model(&self) -> Result<Vec<(String, String)>, String> {
        self.validate()?;
        // Vue template 的 computed/state/action 關聯在此攤平成 render model，Yew view 可依 key 前綴渲染欄位與按鈕。
        logging::debug("frontend.main", "render_model", format!("fields={}, actions={}", self.fields.len(), self.actions.len()));
        let mut rows = vec![("title".to_string(), self.title.clone()), ("route".to_string(), self.route.clone()), ("loading".to_string(), self.loading.to_string())];
        if let Some(error)=&self.error { rows.push(("error".to_string(), error.clone())); }
        for field in &self.fields { rows.push((format!("field:{}", field.name), format!("{}|required={}|value={}", field.label, field.required, field.value.clone().unwrap_or_default()))); }
        for action in &self.actions { rows.push((format!("action:{}", action.name), format!("{}|target={}", action.label, action.target_route.clone().unwrap_or_default()))); }
        Ok(rows)
    }
}

pub fn default_fields() -> Vec<UiField> {
    logging::debug("frontend.main", "default_fields", "build fields from translated component contract");
    vec![UiField { name: "name".to_string(), label: "Name".to_string(), required: true, value: None }, UiField { name: "description".to_string(), label: "Description".to_string(), required: false, value: None }]
}

pub fn default_actions() -> Vec<UiAction> {
    logging::debug("frontend.main", "default_actions", "build action list");
    vec![UiAction { name: "save".to_string(), label: "Save".to_string(), target_route: None }, UiAction { name: "back".to_string(), label: "Back".to_string(), target_route: Some("/dashboard".to_string()) }]
}

pub fn render_model(component: &MainComponent) -> Vec<(String, String)> {
    logging::debug("frontend.main", "render_model_compat", "compat wrapper");
    component.render_model().unwrap_or_else(|e| vec![("error".to_string(), e)])
}

fn main() {
    let component = app::AppComponent::default();
    let _ = component.render_model();
}
